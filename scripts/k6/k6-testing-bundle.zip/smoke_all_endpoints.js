// README: run commands
// BASE_URL="https://snoutiq.com/backend" k6 run scripts/k6/smoke_all_endpoints.js
// AUTH_MODE=bearer EMAIL="you@example.com" PASSWORD="secret" k6 run scripts/k6/smoke_all_endpoints.js
// ALLOW_MUTATIONS=true PAYLOADS_FILE=path/to/payloads.json k6 run scripts/k6/smoke_all_endpoints.js

import http from "k6/http";
import { check } from "k6";
import { SharedArray } from "k6/data";

const BASE_URL = (__ENV.BASE_URL || "https://snoutiq.com/backend").replace(/\/$/, "");
const AUTH_MODE = (__ENV.AUTH_MODE || "none").toLowerCase();
const LOGIN_URL = __ENV.LOGIN_URL || "/api/login";
const EMAIL = __ENV.EMAIL;
const PASSWORD = __ENV.PASSWORD;
const ALLOW_MUTATIONS = (__ENV.ALLOW_MUTATIONS || "false").toLowerCase() === "true";
const PAYLOADS_FILE = __ENV.PAYLOADS_FILE;

const SAFE_METHODS = ["GET", "HEAD", "OPTIONS"];
const MUTATING_METHODS = ["POST", "PUT", "PATCH", "DELETE"];

const routes = new SharedArray("routes", () => {
  const filePath = __ENV.ROUTES_FILE || "./routes.json";
  try {
    return JSON.parse(open(filePath));
  } catch (err) {
    console.error(`Failed to load routes from ${filePath}: ${err}`);
    return [];
  }
});

const payloadTemplates = new SharedArray("payloadTemplates", () => {
  if (!PAYLOADS_FILE) return [{}];
  try {
    const content = JSON.parse(open(PAYLOADS_FILE));
    return [content];
  } catch (err) {
    console.error(`Failed to load payloads file ${PAYLOADS_FILE}: ${err}`);
    return [{}];
  }
});

const summary = {
  tested: 0,
  passed: 0,
  failed: 0,
  authRequired: 0,
  skippedMutations: 0,
  skippedMissingPayload: 0,
  failures: [],
  slow: [],
};

export const options = {
  scenarios: {
    smoke: {
      executor: "shared-iterations",
      vus: 1,
      iterations: 1,
    },
  },
};

export function setup() {
  if (AUTH_MODE !== "bearer") return { token: null, loginStatus: null };
  if (!EMAIL || !PASSWORD) {
    console.warn("AUTH_MODE=bearer set but EMAIL or PASSWORD missing; will run as public.");
    return { token: null, loginStatus: null };
  }

  const url = buildUrl(LOGIN_URL);
  const payload = JSON.stringify({ email: EMAIL, password: PASSWORD });
  const res = http.post(url, payload, {
    headers: { "Content-Type": "application/json" },
  });

  const token = extractToken(res);
  if (!token) {
    console.warn(`Login failed (status ${res.status}). Continuing without auth.`);
  }

  return {
    token,
    loginStatus: res.status,
  };
}

function selectMethod(methods = []) {
  const upper = methods.map((m) => String(m).toUpperCase());
  const safe = SAFE_METHODS.find((m) => upper.includes(m));
  if (safe) return safe;
  const mutating = MUTATING_METHODS.find((m) => upper.includes(m));
  return mutating || upper[0] || null;
}

function shouldSkipMutation(method) {
  return MUTATING_METHODS.includes(method) && !ALLOW_MUTATIONS;
}

function getPayloadFor(route, method) {
  const templates = payloadTemplates[0] || {};
  const direct = templates[`${method} ${route.uri}`] || templates[route.uri];
  return direct || null;
}

function buildUrl(uri = "") {
  const normalized = uri.startsWith("/") ? uri : `/${uri}`;
  return `${BASE_URL}${normalized}`;
}

function fillPathParams(uri = "") {
  return uri.replace(/{([^}]+)}/g, (_, key) => placeholderFor(key));
}

function placeholderFor(key) {
  const lower = String(key).toLowerCase();
  if (lower.includes("email")) return "test@example.com";
  if (lower.includes("phone")) return "1234567890";
  if (lower.includes("token")) return "sample-token";
  if (lower.includes("slug")) return "sample-slug";
  if (lower.includes("uuid")) return "00000000-0000-0000-0000-000000000001";
  if (lower.includes("date")) return "2024-01-01";
  return "1";
}

function isAuthMiddleware(route = {}) {
  const mids = Array.isArray(route.middleware) ? route.middleware : route.middleware ? [route.middleware] : [];
  return mids.some((m) => {
    const lower = String(m).toLowerCase();
    return lower.includes("auth") || lower.includes("token");
  });
}

function extractToken(res) {
  try {
    const body = res.json();
    if (body?.token) return body.token;
    if (body?.access_token) return body.access_token;
    if (body?.data?.token) return body.data.token;
  } catch (err) {
    // Non-JSON response; ignore.
  }
  return null;
}

function isSuccessStatus(status) {
  return status >= 200 && status < 400;
}

export default function main(data) {
  const baseHeaders = {};
  if (data?.token) {
    baseHeaders.Authorization = `Bearer ${data.token}`;
  }

  for (const route of routes) {
    const method = selectMethod(route.methods);
    if (!method) continue;

    if (shouldSkipMutation(method)) {
      summary.skippedMutations += 1;
      continue;
    }

    const isMutation = MUTATING_METHODS.includes(method);
    let body = null;
    if (isMutation) {
      const payload = getPayloadFor(route, method);
      if (!payload) {
        summary.skippedMissingPayload += 1;
        continue;
      }
      body = JSON.stringify(payload);
    }

    const uriWithParams = fillPathParams(route.uri);
    const url = buildUrl(uriWithParams);

    const headers = { ...baseHeaders };
    if (isMutation) {
      headers["Content-Type"] = headers["Content-Type"] || "application/json";
    }

    const res = http.request(method, url, body, { headers });
    const status = res.status || 0;
    const isAuthStatus = status === 401 || status === 403;

    summary.tested += 1;

    if (res.timings?.duration > 1500) {
      summary.slow.push({ method, url, duration: res.timings.duration });
    }

    if (isAuthStatus && !data?.token) {
      summary.authRequired += 1;
      continue;
    }

    const ok = isSuccessStatus(status);
    check(res, {
      [`${method} ${route.uri} => ${status}`]: () => ok,
    });

    if (ok) {
      summary.passed += 1;
    } else {
      summary.failed += 1;
      summary.failures.push({
        method,
        url,
        status,
        reason: isAuthStatus ? "auth_failed" : "http_error",
      });
    }
  }
}

export function handleSummary() {
  const lines = [
    "---- API Smoke Summary ----",
    `Routes tested: ${summary.tested}`,
    `Passed: ${summary.passed}`,
    `Failed: ${summary.failed}`,
    `Auth required (skipped): ${summary.authRequired}`,
    `Skipped mutations (ALLOW_MUTATIONS=false): ${summary.skippedMutations}`,
    `Skipped (no payload provided): ${summary.skippedMissingPayload}`,
  ];

  if (summary.failures.length) {
    lines.push("Failures:");
    summary.failures.forEach((f) => {
      lines.push(`  - ${f.status} ${f.method} ${f.url} (${f.reason})`);
    });
  }

  if (summary.slow.length) {
    lines.push("Slow endpoints (>1500ms):");
    summary.slow.forEach((s) => {
      lines.push(`  - ${s.duration.toFixed(1)}ms ${s.method} ${s.url}`);
    });
  }

  return {
    stdout: lines.join("\n") + "\n",
    "scripts/k6/failures.json": JSON.stringify(summary.failures, null, 2),
  };
}
